"""Regras de seleção e organização da fila de links de páginas."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from analisar_html import PageAnalysis


@dataclass(frozen=True)
class PendingPage:
    page_id: str
    depth: int
    api_context: bool = False
    parent_id: str | None = None


def selecionar_paginas(
    analysis: PageAnalysis,
    parent: PendingPage,
    *,
    max_depth: int,
    follow_all_on_api_page: bool = False,
) -> list[PendingPage]:
    if parent.depth >= max_depth:
        return []
    parent_context = parent.api_context or bool(analysis.attachments)
    selected = []
    # Links com títulos relevantes em primeiro lugar; depois referências explícitas a filhos.
    ordered = sorted(
        analysis.links,
        key=lambda link: (not link.matched_api, not (link.child_reference or link.matched_method)),
    )
    for link in ordered:
        should_follow = (
            link.matched_api
            or link.child_reference
            or (parent_context and link.matched_method)
            or (parent_context and follow_all_on_api_page)
        )
        if should_follow:
            selected.append(
                PendingPage(
                    page_id=link.page_id,
                    depth=parent.depth + 1,
                    api_context=parent_context or link.matched_api or link.matched_method,
                    parent_id=parent.page_id,
                )
            )
    return selected


def montar_fila_inicial(page_id: str) -> deque[PendingPage]:
    return deque([PendingPage(page_id=page_id, depth=0)])
