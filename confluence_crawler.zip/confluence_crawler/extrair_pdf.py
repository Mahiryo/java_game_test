"""Segunda requisição: FlyingPDF, inclusive tarefas assíncronas quando disponíveis."""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import quote

from bs4 import BeautifulSoup

from config import Config
from confluence_urls import resolve_url
from requisicoes import HTTPClient


def _task_id(raw: bytes) -> str | None:
    soup = BeautifulSoup(raw, "html.parser")
    meta = soup.find("meta", attrs={"name": "ajs-taskId"})
    if meta and meta.get("content"):
        return str(meta["content"])
    match = re.search(rb'ajs-taskId["\']\s*[:=]\s*["\']([^"\']+)', raw)
    return match.group(1).decode("utf-8") if match else None


def _result_url(progress: dict) -> str | None:
    result = progress.get("result")
    if isinstance(result, str) and result:
        return result
    if isinstance(result, dict):
        for key in ("downloadUrl", "downloadURL", "url", "href", "location"):
            if isinstance(result.get(key), str) and result[key]:
                return result[key]
    return None


def extrair_pdf(client: HTTPClient, config: Config, page_id: str, output: Path) -> Path:
    url = f"{config.base_url}/spaces/flyingpdf/pdfpageexport.action?pageId={quote(page_id)}"
    raw = client.get(url, accept="application/pdf,text/html,*/*", allow_external=config.allow_external_pdf_url)
    if not raw.startswith(b"%PDF-"):
        task_id = _task_id(raw)
        if not task_id:
            raise ValueError("FlyingPDF não retornou PDF ou identificador de tarefa; verifique a sessão.")
        for _ in range(config.max_pdf_polls):
            progress_url = f"{config.base_url}/api/v2/pdfexporttask/progress/{quote(task_id)}"
            progress_raw = client.get(progress_url, accept="application/json")
            progress = json.loads(progress_raw.decode("utf-8-sig"))
            state = str(progress.get("state") or progress.get("status") or "").lower()
            if state in {"failed", "error", "cancelled"}:
                raise ValueError(f"Exportação PDF falhou: {state}")
            destination = _result_url(progress)
            if destination:
                pdf_url = resolve_url(config.base_url, destination)
                raw = client.get(
                    pdf_url,
                    accept="application/pdf,*/*",
                    allow_external=config.allow_external_pdf_url,
                )
                break
        else:
            raise TimeoutError("Exportação PDF não finalizou dentro de MAX_PDF_POLLS.")

    if not raw.startswith(b"%PDF-"):
        raise ValueError("Resposta de exportação não contém um PDF válido.")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(raw)
    return output
