"""Primeira etapa: recuperar HTML renderizado e alternativas de API."""
from __future__ import annotations

import json
import logging
from urllib.parse import quote

from bs4 import BeautifulSoup

from config import Config
from requisicoes import HTTPClient, RequestBudgetExceeded, RequestFailed, RateLimitExceeded

LOG = logging.getLogger(__name__)


def _html_valido(content: str) -> bool:
    soup = BeautifulSoup(content, "html.parser")
    if soup.select_one('form[id*="login"], form[action*="login.action"], form[action*="saml" i]'):
        return False
    return bool(soup.select_one("html, div, main, table, a, p, ac\\:structured-macro"))


def extrair_html(client: HTTPClient, config: Config, page_id: str) -> str:
    modes = ["html", "dc", "cloud"] if config.html_mode == "auto" else [config.html_mode]
    errors: list[str] = []
    for mode in modes:
        try:
            if mode == "html":
                raw = client.get(
                    f"{config.base_url}/pages/viewpage.action?pageId={quote(page_id)}",
                    accept="text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
                )
                text = raw.decode("utf-8-sig", errors="replace")
                if not _html_valido(text):
                    raise ValueError("HTML vazio ou página de login")
                return text

            if mode == "dc":
                raw = client.get(
                    f"{config.base_url}/rest/api/content/{quote(page_id)}?expand=body.view",
                    accept="application/json",
                )
                payload = json.loads(raw.decode("utf-8-sig"))
            else:
                raw = client.get(
                    f"{config.base_url}/api/v2/pages/{quote(page_id)}?body-format=view",
                    accept="application/json",
                )
                payload = json.loads(raw.decode("utf-8-sig"))

            value = payload.get("body", {}).get("view", {}).get("value")
            if not isinstance(value, str) or not value.strip():
                raise ValueError("API não retornou body.view.value")
            return value
        except (RequestBudgetExceeded, RateLimitExceeded):
            raise
        except (RequestFailed, ValueError, KeyError, json.JSONDecodeError, AttributeError) as exc:
            errors.append(f"{mode}: {exc}")
            LOG.warning("Página %s: falha no modo %s: %s", page_id, mode, exc)
    raise RequestFailed("Não foi possível obter HTML: " + " | ".join(errors))
