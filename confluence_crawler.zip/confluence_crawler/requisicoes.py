"""Cliente HTTP: autenticação, ritmo, redirects, 429 e orçamento total."""
from __future__ import annotations

import base64
import email.utils
import logging
import random
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests

from config import Config
from confluence_urls import same_origin

LOG = logging.getLogger(__name__)


class RequestBudgetExceeded(RuntimeError):
    pass


class RequestFailed(RuntimeError):
    pass


class RateLimitExceeded(RequestFailed):
    """O servidor manteve o bloqueio HTTP 429 após os retries permitidos."""
    pass


class HTTPClient:
    def __init__(self, config: Config, session: requests.Session | None = None):
        self.config = config
        self.session = session or requests.Session()
        self.count = 0
        self.last_finished: float | None = None

    def _headers(self, url: str, accept: str) -> dict[str, str]:
        headers = {
            "User-Agent": "ConfluenceDocumentCrawler/1.0",
            "Accept": accept,
            "X-Atlassian-Token": "no-check",
        }
        if same_origin(self.config.base_url, url):
            if self.config.pat:
                headers["Authorization"] = f"Bearer {self.config.pat}"
            elif self.config.email and self.config.api_token:
                value = base64.b64encode(f"{self.config.email}:{self.config.api_token}".encode()).decode()
                headers["Authorization"] = f"Basic {value}"
            if self.config.cookie:
                headers["Cookie"] = self.config.cookie
        return headers

    def _pace(self) -> None:
        if self.count >= self.config.max_requests:
            raise RequestBudgetExceeded(f"Limite de {self.config.max_requests} requisições atingido")
        if self.last_finished is not None:
            elapsed = time.monotonic() - self.last_finished
            delay = self.config.interval - elapsed
            if delay > 0:
                time.sleep(delay)
        self.count += 1

    def _retry_after_seconds(self, response: requests.Response) -> float | None:
        header = response.headers.get("Retry-After", "").strip()
        if not header:
            return None
        try:
            return max(0.0, float(header))
        except ValueError:
            try:
                date = email.utils.parsedate_to_datetime(header)
                if date.tzinfo is None:
                    date = date.replace(tzinfo=timezone.utc)
                return max(0.0, (date - datetime.now(timezone.utc)).total_seconds())
            except (ValueError, TypeError, IndexError):
                return None

    def _retry_wait(self, response: requests.Response | None, retry_number: int) -> float:
        seconds = self._retry_after_seconds(response) if response is not None else None
        if seconds is None:
            seconds = min(60.0, 2 ** retry_number + random.uniform(0.0, 0.5))
        return min(self.config.max_retry_wait, seconds)

    def get(self, url: str, *, accept: str = "*/*", allow_external: bool = False) -> bytes:
        """Toda tentativa e redirecionamento consome uma unidade de MAX_REQUESTS."""
        initial = urlparse(url)
        if initial.scheme not in {"http", "https"} or not initial.hostname:
            raise RequestFailed("URL com esquema ou host inválido")
        if not same_origin(self.config.base_url, url) and not allow_external:
            raise RequestFailed("URL externa bloqueada")
        current = url
        redirects = 0
        retries = 0
        while True:
            parsed = urlparse(current)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                raise RequestFailed("Redirecionamento inseguro bloqueado")
            if not same_origin(self.config.base_url, current) and not allow_external:
                raise RequestFailed("Redirecionamento externo bloqueado")
            self._pace()
            LOG.debug("HTTP GET [%s/%s] %s", self.count, self.config.max_requests, current)
            response = None
            try:
                # Impede que a biblioteca encaminhe Authorization/Cookie automaticamente em redirects.
                response = self.session.get(
                    current,
                    headers=self._headers(current, accept),
                    timeout=self.config.timeout,
                    allow_redirects=False,
                )
            except requests.RequestException as exc:
                self.last_finished = time.monotonic()
                if retries >= self.config.max_retries:
                    raise RequestFailed(f"Erro de conexão: {type(exc).__name__}: {exc}") from exc
                retries += 1
                time.sleep(self._retry_wait(None, retries))
                continue
            try:
                if response.status_code in {301, 302, 303, 307, 308}:
                    location = response.headers.get("Location", "")
                    if not location or redirects >= self.config.max_redirects:
                        raise RequestFailed("Redirect sem destino ou limite de redirects atingido")
                    current = urljoin(current, location)
                    redirects += 1
                    retries = 0
                    continue
                if response.status_code in {429, 500, 502, 503, 504}:
                    if retries >= self.config.max_retries:
                        if response.status_code == 429:
                            raise RateLimitExceeded("HTTP 429: limite de tentativas atingido; execução interrompida")
                        raise RequestFailed(f"HTTP {response.status_code}: tentativas esgotadas")
                    retries += 1
                    # Um Retry-After maior que o limite permitido encerra o processo
                    # em vez de reenviar antes do prazo informado pelo servidor.
                    original_wait = self._retry_after_seconds(response) if response.status_code == 429 else None
                    if original_wait is not None and original_wait > self.config.max_retry_wait:
                        raise RateLimitExceeded(
                            f"HTTP 429: Retry-After ({original_wait:.1f}s) excede "
                            f"MAX_RETRY_WAIT ({self.config.max_retry_wait:.1f}s)"
                        )
                    wait = self._retry_wait(response, retries)
                    LOG.warning("HTTP %s; aguardando %.1fs antes de tentar novamente", response.status_code, wait)
                    time.sleep(wait)
                    continue
                if response.status_code >= 400:
                    raise RequestFailed(f"HTTP {response.status_code} ao acessar {urlparse(current).path}")
                return response.content
            finally:
                self.last_finished = time.monotonic()
                response.close()

    def close(self) -> None:
        self.session.close()
