"""Execução BFS, controle de loops, arquivos e relatório final."""
from __future__ import annotations

import json
import logging
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from analisar_html import analisar_html
from buscar_paginas import montar_fila_inicial, selecionar_paginas
from config import Config
from extrair_html import extrair_html
from extrair_json import extrair_json
from extrair_pdf import extrair_pdf
from requisicoes import HTTPClient, RequestBudgetExceeded, RateLimitExceeded

LOG = logging.getLogger(__name__)


def executar(config: Config, client: HTTPClient | None = None) -> dict:
    client = client or HTTPClient(config)
    config.output_dir.mkdir(parents=True, exist_ok=True)
    queue = montar_fila_inicial(config.page_id)
    scheduled = {config.page_id}
    visited: set[str] = set()
    report: dict = {
        "inicio": datetime.now(timezone.utc).isoformat(),
        "pagina_inicial": config.page_id,
        "limites": {
            "max_pages": config.max_pages,
            "max_depth": config.max_depth,
            "max_requests": config.max_requests,
            "interval_seconds": config.interval,
        },
        "paginas": [],
        "total_requisicoes": 0,
        "total_paginas": 0,
        "pendentes": [],
        "parada": "fila esgotada",
    }
    try:
        while queue and len(visited) < config.max_pages:
            page = queue.popleft()
            if page.page_id in visited:
                continue
            visited.add(page.page_id)
            LOG.info("Página %s (profundidade %s)", page.page_id, page.depth)
            item: dict = {
                "id": page.page_id,
                "parent_id": page.parent_id,
                "profundidade": page.depth,
                "titulo": None,
                "html": None,
                "pdf": None,
                "json": [],
                "paginas_encontradas": [],
                "erros": [],
            }
            report["paginas"].append(item)
            try:
                html = extrair_html(client, config, page.page_id)
                html_path = config.output_dir / "html" / f"{page.page_id}.html"
                html_path.parent.mkdir(parents=True, exist_ok=True)
                html_path.write_text(html, encoding="utf-8")
                item["html"] = str(html_path)
            except RequestBudgetExceeded:
                report["parada"] = "limite de requisições"
                break
            except RateLimitExceeded as exc:
                item["erros"].append(str(exc))
                report["parada"] = "bloqueio HTTP 429"
                break
            except Exception as exc:
                item["erros"].append(f"GET HTML: {exc}")
                LOG.error("Página %s: %s", page.page_id, exc)
                continue

            analysis = analisar_html(html, config.base_url, page.page_id)
            item["titulo"] = analysis.title
            children = selecionar_paginas(
                analysis,
                page,
                max_depth=config.max_depth,
                follow_all_on_api_page=config.follow_all_on_api_page,
            )
            for child in children:
                if child.page_id not in visited and child.page_id not in scheduled:
                    # Proteção adicional contra filas enormes, sem descartar todas as gerações futuras.
                    if len(scheduled) >= config.max_pages * 4:
                        break
                    scheduled.add(child.page_id)
                    queue.append(child)
                    item["paginas_encontradas"].append(child.page_id)

            if config.export_pdf:
                try:
                    pdf_path = config.output_dir / "pdf" / f"{page.page_id}.pdf"
                    item["pdf"] = str(extrair_pdf(client, config, page.page_id, pdf_path))
                except RequestBudgetExceeded:
                    report["parada"] = "limite de requisições"
                    break
                except RateLimitExceeded as exc:
                    item["erros"].append(str(exc))
                    report["parada"] = "bloqueio HTTP 429"
                    break
                except Exception as exc:
                    item["erros"].append(f"EXPORT PDF: {exc}")
                    LOG.warning("Página %s: PDF não salvo: %s", page.page_id, exc)

            if report["parada"] == "bloqueio HTTP 429":
                break

            if config.download_json:
                for attachment in analysis.attachments:
                    try:
                        path = extrair_json(client, config, attachment, page.page_id)
                        item["json"].append(str(path))
                    except RequestBudgetExceeded:
                        report["parada"] = "limite de requisições"
                        break
                    except RateLimitExceeded as exc:
                        item["erros"].append(str(exc))
                        report["parada"] = "bloqueio HTTP 429"
                        break
                    except Exception as exc:
                        item["erros"].append(f"DOWNLOAD JSON [{attachment.name}]: {exc}")
                        LOG.warning("Página %s: anexo %s: %s", page.page_id, attachment.name, exc)
                if report["parada"] in {"limite de requisições", "bloqueio HTTP 429"}:
                    break
        if queue and len(visited) >= config.max_pages and report["parada"] == "fila esgotada":
            report["parada"] = "limite de páginas"
    except KeyboardInterrupt:
        report["parada"] = "interrompido pelo usuário"
        LOG.warning("Execução interrompida pelo usuário")
    finally:
        report["total_requisicoes"] = client.count
        report["total_paginas"] = len(visited)
        report["pendentes"] = [asdict(page) for page in queue]
        report["fim"] = datetime.now(timezone.utc).isoformat()
        file = config.output_dir / "relatorio.json"
        file.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        LOG.info("Relatório: %s", file.resolve())
        client.close()
    return report
