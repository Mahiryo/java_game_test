# Crawler Confluence — HTML, PDF e Swagger JSON

Projeto em Python para visitar uma página Confluence inicial e identificar páginas ligadas a documentação de APIs pelos títulos, `href` e classes HTML. Processa a fila em profundidade limitada, salva HTML, exporta PDF via FlyingPDF e baixa anexos Swagger/OpenAPI `.json`.

## Preparação

Requer **Python 3.10+**.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

No Windows, ative o ambiente com `.venv\\Scripts\\activate`. Edite o `.env` e informe `CONFLUENCE_BASE_URL` e `CONFLUENCE_PAGE_ID`. Preencha **uma** forma de autenticação: PAT (`CONFLUENCE_PAT`) ou e-mail + API token (`CONFLUENCE_EMAIL` e `CONFLUENCE_API_TOKEN`), ou cookie de sessão (`CONFLUENCE_COOKIE`). PAT e cookie podem ser utilizados juntos. Nunca versione `.env` ou cookies reais.

```bash
python main.py
```

Também é possível sobrescrever o Page ID de forma direta:

```bash
python main.py --page-id 740220471 --max-pages 20 --max-depth 2
python main.py --page-id 'https://site/pages/viewpage.action?pageId=740220471' --no-pdf
```

## Etapas

1. `config.py` — lê `.env`, valida base, ID e limites.
2. `requisicoes.py` — cliente HTTP compartilhado: headers, PAT/Basic/Cookie, intervalos, `429` e contagem total.
3. `extrair_html.py` — **GET HTML** da página por `pageId`. Em `auto`, tenta HTML renderizado, REST DC `body.view` e Cloud API v2 `body.view`.
4. `analisar_html.py` — identifica `href`, classes (`confluence-embedded-file`, `childpages-macro`, `pagetree`) e anexos `.json` usando `data-file-src`, `aria-label`, `data-linked-resource-id`.
5. `buscar_paginas.py` — seleciona páginas com nomes MS, microserviço, técnico, APID, API, Swagger, ou explicitamente filhas; em contexto de API também busca métodos HTTP (GET, POST, PUT, PATCH, DELETE etc.). Evita reprocessamento e limita profundidade.
6. `extrair_pdf.py` — **EXPORT PDF** via `/spaces/flyingpdf/pdfpageexport.action?pageId=...`, validando `%PDF-`. Quando há `ajs-taskId`, consulta a conclusão em `/api/v2/pdfexporttask/progress/` com limite de polls.
7. `extrair_json.py` — **DOWNLOAD JSON** de anexos descobertos; valida sintaxe e, por padrão, presença de estrutura Swagger/OpenAPI antes de salvar.
8. `controle.py` — executa o ciclo de páginas, registra erros individuais e gera `output/relatorio.json`.
9. `main.py` — ponto de entrada.

## Organização da saída

```text
output/
  html/740220471.html
  pdf/740220471.pdf
  json/740220471/swagger api-customer-information-v1.json
  relatorio.json
```

## Controles e observações

- **`REQUEST_INTERVAL=3`**: intervalo mínimo entre **todas** as tentativas HTTP, inclusive retries, redirects e polling de PDF.
- **`MAX_REQUESTS=100`**: limite global. Fallback de HTML, polling de PDF, redirects e retries também contam.
- **`MAX_PAGES=30`**: limite de páginas processadas, com guarda de visitados.
- **`MAX_DEPTH=3`**: limite de níveis abaixo da página inicial.
- **`MAX_RETRIES=2`**: tentativas adicionais após `429`, `5xx` e erros de conexão; `Retry-After` é respeitado até `MAX_RETRY_WAIT`.
- **`MAX_PDF_POLLS=8`**: consultas de progresso máximas para PDF assíncrono.
- **`FOLLOW_ALL_ON_API_PAGE=false`**: conserva a seleção por títulos, métodos e macros de filhos. Ative quando os nomes de métodos não forem identificáveis pelos filtros, ciente de que amplia a busca.
- **`STRICT_SWAGGER=true`**: JSON que não pareça Swagger/OpenAPI é descartado; use `false` para salvar todo `.json` anexado à página.
- **`ALLOW_EXTERNAL_PDF_URL=true`**: permite redirecionamento/URL assinada externa para exportação PDF Cloud, **sem encaminhar PAT ou Cookie como headers**. Desative caso o seu ambiente proíba downloads externos.

**Não é possível garantir ausência absoluta de HTTP 429**, pois o servidor controla os limites. O cliente reduz sua incidência com pacing e espera de `Retry-After`, e encerra quando os limites são atingidos. Um login via SSO pode retornar uma página HTML sem os links/documentação; nesse caso é necessário autenticação válida. Algumas instâncias não disponibilizam FlyingPDF ou exigem autorização específica.

**Descoberta de filhos:** links com Page ID no HTML são encontrados. Links Confluence `/display/SPACE/Titulo` sem ID numérico, filhos carregados apenas via JavaScript, ou filhos ocultos atrás da API de hierarquia não são automaticamente identificados por este modo baseado em `href` e classes. Não é feito crawling irrestrito do site. Caso a instância use apenas esses formatos, a busca deve ser ampliada por API de children.

## Testes locais

```bash
python -m unittest discover -s tests -v
```

Não há requisições de rede nesses testes; usam fixtures e clientes falsos.
