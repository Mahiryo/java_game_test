"""Segunda etapa: extrair IDs, links por href/classes e arquivos JSON anexados."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlparse

from bs4 import BeautifulSoup, Tag

from confluence_urls import page_id_from_value, resolve_url, same_origin

API_TITLE_RE = re.compile(
    r"\bms\b|micro[\s_-]*servi[cç]o|microsservi[cç]o|\bt[eé]cnic[oa]s?\b|\bapid\b|"
    r"\bopenapi\b|\bswagger\b|documenta[cç][aã]o\s+(?:da\s+)?api|\bapi\b",
    re.IGNORECASE,
)
METHOD_RE = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b", re.IGNORECASE)
CHILD_CLASS_RE = re.compile(r"childpages|child-page|pagetree|children|childpages-macro", re.IGNORECASE)
CONTENT_SELECTORS = ["#main-content", ".wiki-content", ".ak-renderer-document", "#content", "main"]


@dataclass(frozen=True)
class PageLink:
    page_id: str
    title: str
    url: str
    matched_api: bool
    matched_method: bool
    child_reference: bool


@dataclass(frozen=True)
class JsonAttachment:
    name: str
    url: str
    resource_id: str = ""


@dataclass
class PageAnalysis:
    title: str
    links: list[PageLink] = field(default_factory=list)
    attachments: list[JsonAttachment] = field(default_factory=list)


def _content_root(soup: BeautifulSoup) -> Tag | BeautifulSoup:
    for selector in CONTENT_SELECTORS:
        el = soup.select_one(selector)
        if el is not None:
            return el
    return soup


def _child_reference(anchor: Tag) -> bool:
    if anchor.get("data-linked-resource-type") == "page":
        return True
    for el in [anchor, *anchor.parents]:
        if not isinstance(el, Tag) or el.name in {"html", "body"}:
            break
        class_list = " ".join(el.get("class", []))
        if CHILD_CLASS_RE.search(class_list):
            return True
    return False


def _is_attachment_candidate(anchor: Tag) -> bool:
    classes = anchor.get("class", [])
    href = anchor.get("href", "") or ""
    src = anchor.get("data-file-src", "") or ""
    return (
        "confluence-embedded-file" in classes
        or anchor.get("data-linked-resource-type") == "attachment"
        or "/download/attachments/" in href
        or "/download/attachments/" in src
    )


def analisar_html(html: str, base_url: str, page_id: str) -> PageAnalysis:
    soup = BeautifulSoup(html, "html.parser")
    root = _content_root(soup)
    heading = soup.select_one("h1.pagetitle, h1#title-text, #title-heading, h1")
    title = heading.get_text(" ", strip=True) if heading else f"Página {page_id}"
    result = PageAnalysis(title=title)
    link_seen: set[str] = set()
    attachment_seen: set[str] = set()

    for anchor in root.select("a[href], a[data-file-src]"):
        href = (anchor.get("href") or "").strip()
        data_src = (anchor.get("data-file-src") or "").strip()
        raw_url = data_src if _is_attachment_candidate(anchor) and "/download/attachments/" in data_src else (href or data_src)
        if not raw_url or raw_url.startswith(("#", "javascript:", "mailto:")):
            continue
        link_url = resolve_url(base_url, raw_url)
        if not same_origin(base_url, link_url):
            continue

        name = (
            anchor.get("aria-label")
            or anchor.get("data-linked-resource-default-alias")
            or anchor.get("title")
            or unquote(urlparse(link_url).path.rsplit("/", 1)[-1])
        ).strip()
        if _is_attachment_candidate(anchor):
            # A extensão deve vir do nome, URL ou data-file-src. MIME costuma ser octet-stream.
            names = " ".join([name, unquote(urlparse(link_url).path), anchor.get("data-file-src", "") or ""])
            if re.search(r"\.json(?:\b|$|\?)", names, re.IGNORECASE):
                resource_id = (anchor.get("data-linked-resource-id") or "").strip()
                key = resource_id or link_url.split("?", 1)[0]
                if key not in attachment_seen:
                    attachment_seen.add(key)
                    result.attachments.append(JsonAttachment(name, link_url, resource_id))
            # Não interpretar download de anexo como link para página.
            continue

        page_id_found = page_id_from_value(link_url)
        if not page_id_found or page_id_found == page_id or page_id_found in link_seen:
            continue
        if anchor.find_parent("nav"):
            continue
        text = (anchor.get_text(" ", strip=True) or anchor.get("title") or "").strip()
        if not text:
            text = f"Página {page_id_found}"
        link_seen.add(page_id_found)
        result.links.append(
            PageLink(
                page_id=page_id_found,
                title=text,
                url=link_url,
                matched_api=bool(API_TITLE_RE.search(text)),
                matched_method=bool(METHOD_RE.search(text)),
                child_reference=_child_reference(anchor),
            )
        )
    return result
