"""URLs e identificação de páginas do Confluence."""
from __future__ import annotations

import re
from urllib.parse import parse_qs, urljoin, urlparse


def page_id_from_value(value: str) -> str | None:
    value = value.strip()
    if value.isdigit():
        return value
    parsed = urlparse(value)
    params = parse_qs(parsed.query)
    for key in ("pageId", "pageid"):
        if key in params and params[key][0].isdigit():
            return params[key][0]
    match = re.search(r"/pages/(\d+)(?:/|$)", parsed.path)
    return match.group(1) if match else None


def resolve_url(base_url: str, href: str) -> str:
    """Resolve links absolutos e relativos, incluindo contextos /wiki ou /confluence."""
    href = href.strip()
    parsed = urlparse(href)
    if parsed.scheme:
        return href
    base_path = urlparse(base_url).path.rstrip("/")
    if href.startswith("/") and base_path and not (
        href.startswith(base_path + "/") or href == base_path
    ):
        # Links de anexos retornados pela API podem não incluir o context path.
        return base_url.rstrip("/") + href
    return urljoin(base_url.rstrip("/") + "/", href)


def same_origin(base_url: str, url: str) -> bool:
    first = urlparse(base_url)
    other = urlparse(url)
    return first.scheme.lower() == other.scheme.lower() and first.netloc.lower() == other.netloc.lower()
