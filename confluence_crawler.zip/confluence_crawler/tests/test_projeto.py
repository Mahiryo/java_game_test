from __future__ import annotations

import io
import json
import tempfile
import unittest
from pathlib import Path

import requests

from analisar_html import analisar_html
from buscar_paginas import PendingPage, selecionar_paginas
from config import Config
from confluence_urls import page_id_from_value, resolve_url
from controle import executar
from extrair_json import _is_swagger
from requisicoes import HTTPClient, RequestBudgetExceeded, RequestFailed

FIXTURES = Path(__file__).parent / "fixtures"
BASE = "https://confluence.exemplo.com"


class HTMLTests(unittest.TestCase):
    def test_find_links_and_swagger_with_octet_stream(self):
        page = (FIXTURES / "pagina_raiz.html").read_text(encoding="utf-8")
        analysis = analisar_html(page, BASE, "740220471")
        self.assertEqual(analysis.title, "Documentação Técnica")
        self.assertEqual({x.page_id for x in analysis.links}, {"777", "888", "999"})
        self.assertEqual(len(analysis.attachments), 1)
        attachment = analysis.attachments[0]
        self.assertEqual(attachment.resource_id, "774212507")
        self.assertEqual(attachment.name, "swagger api-customer-information-v1.json")
        self.assertIn("/download/attachments/740220471/", attachment.url)
        self.assertIn("api=v2", attachment.url)
        self.assertEqual(len([x for x in analysis.links if x.page_id == "777"]), 1)

    def test_selection_not_crawl_unrelated(self):
        analysis = analisar_html((FIXTURES / "pagina_raiz.html").read_text(), BASE, "740220471")
        selected = selecionar_paginas(analysis, PendingPage("740220471", 0), max_depth=2)
        self.assertEqual({p.page_id for p in selected}, {"777", "888"})
        self.assertEqual(selecionar_paginas(analysis, PendingPage("740220471", 2), max_depth=2), [])

    def test_ids_and_context_urls(self):
        self.assertEqual(page_id_from_value("/pages/viewpage.action?pageId=123"), "123")
        self.assertEqual(page_id_from_value("https://site/wiki/pages/456/Page"), "456")
        self.assertIsNone(page_id_from_value("/display/ABC/Documentacao"))
        self.assertEqual(
            resolve_url("https://site/wiki", "/download/attachments/1/swagger.json"),
            "https://site/wiki/download/attachments/1/swagger.json",
        )

    def test_swagger_structure(self):
        self.assertTrue(_is_swagger({"openapi": "3.0.2", "paths": {}}))
        self.assertTrue(_is_swagger({"swagger": "2.0"}))
        self.assertFalse(_is_swagger({"some": "json"}))


class FakeClient:
    def __init__(self):
        self.count = 0
        self.closed = False
        self.root = (FIXTURES / "pagina_raiz.html").read_bytes()
        self.child = (FIXTURES / "pagina_filha.html").read_bytes()

    def get(self, url, **kwargs):
        self.count += 1
        if "viewpage.action" in url:
            return self.child if "777" in url or "888" in url else self.root
        if "pdfpageexport.action" in url:
            return b"%PDF-1.5\nmock pdf bytes for tests"
        if ".json" in url:
            return json.dumps({"openapi": "3.0.1", "info": {"title": "Customer API"}, "paths": {}}).encode()
        raise AssertionError(f"Unexpected URL: {url}")

    def close(self):
        self.closed = True


class ExecutionTests(unittest.TestCase):
    def test_html_pdf_json_pipeline(self):
        with tempfile.TemporaryDirectory() as td:
            config = Config(
                base_url=BASE, page_id="740220471", output_dir=Path(td),
                max_pages=2, max_depth=2, max_requests=50, interval=0,
            )
            client = FakeClient()
            result = executar(config, client)
            self.assertEqual(result["total_paginas"], 2)
            self.assertEqual(result["total_requisicoes"], 5)
            self.assertEqual(result["parada"], "limite de páginas")
            self.assertTrue((Path(td) / "html/740220471.html").exists())
            self.assertTrue((Path(td) / "pdf/740220471.pdf").exists())
            self.assertTrue((Path(td) / "json/740220471/swagger api-customer-information-v1.json").exists())
            self.assertTrue((Path(td) / "relatorio.json").exists())
            self.assertTrue(client.closed)

    def test_without_pdf_and_json(self):
        with tempfile.TemporaryDirectory() as td:
            config = Config(
                base_url=BASE, page_id="740220471", output_dir=Path(td),
                max_pages=1, max_depth=0, max_requests=10,
                export_pdf=False, download_json=False,
            )
            result = executar(config, FakeClient())
            self.assertEqual(result["total_requisicoes"], 1)
            self.assertEqual(result["total_paginas"], 1)
            self.assertEqual(len(result["paginas"][0]["json"]), 0)


class ResponseFactory:
    @staticmethod
    def make(code, content=b"ok", headers=None):
        response = requests.Response()
        response.status_code = code
        response._content = content
        response.raw = io.BytesIO(content)
        response.headers.update(headers or {})
        return response


class FakeSession:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return next(self.responses)

    def close(self):
        pass


class HTTPTests(unittest.TestCase):
    def test_429_retry_and_budget(self):
        config = Config(base_url=BASE, page_id="123", interval=0, max_retries=1, max_requests=2)
        session = FakeSession([
            ResponseFactory.make(429, headers={"Retry-After": "0"}),
            ResponseFactory.make(200, b"done"),
        ])
        client = HTTPClient(config, session=session)
        self.assertEqual(client.get(BASE + "/page"), b"done")
        self.assertEqual(client.count, 2)
        with self.assertRaises(RequestBudgetExceeded):
            client.get(BASE + "/second")

    def test_cross_origin_redirect_drops_credentials(self):
        config = Config(base_url=BASE, page_id="123", pat="secret", cookie="JSESSIONID=abc", interval=0)
        session = FakeSession([
            ResponseFactory.make(302, headers={"Location": "https://cdn.example.net/signed.pdf"}),
            ResponseFactory.make(200, b"%PDF-1.4"),
        ])
        client = HTTPClient(config, session=session)
        client.get(BASE + "/pdf", allow_external=True)
        self.assertIn("Authorization", session.calls[0][1]["headers"])
        self.assertIn("Cookie", session.calls[0][1]["headers"])
        self.assertNotIn("Authorization", session.calls[1][1]["headers"])
        self.assertNotIn("Cookie", session.calls[1][1]["headers"])
        self.assertEqual(client.count, 2)

    def test_external_json_link_forbidden(self):
        config = Config(base_url=BASE, page_id="123")
        client = HTTPClient(config, session=FakeSession([]))
        with self.assertRaises(RequestFailed):
            client.get("https://evil.example/swagger.json")


class MoreFlowTests(unittest.TestCase):
    def test_cloud_pdf_task_polling(self):
        from extrair_pdf import extrair_pdf
        class PdfClient:
            def __init__(self):
                self.responses = iter([
                    b'<html><meta content="abc987" name="ajs-taskId"></html>',
                    b'{"state":"RUNNING"}',
                    b'{"state":"COMPLETE", "result":"/download/exports/abc987.pdf"}',
                    b'%PDF-1.7\nfixture',
                ])
                self.calls = []
            def get(self, url, **kwargs):
                self.calls.append(url)
                return next(self.responses)
        with tempfile.TemporaryDirectory() as td:
            config = Config(base_url=BASE, page_id="123", interval=0, output_dir=Path(td))
            client = PdfClient()
            destination = extrair_pdf(client, config, "123", Path(td) / "pdf/123.pdf")
            self.assertTrue(destination.read_bytes().startswith(b"%PDF-"))
            self.assertEqual(len(client.calls), 4)
            self.assertTrue(client.calls[-1].endswith("/download/exports/abc987.pdf"))

    def test_429_exhausted_is_stop_condition(self):
        from requisicoes import RateLimitExceeded
        config = Config(base_url=BASE, page_id="123", interval=0, max_retries=0)
        session = FakeSession([ResponseFactory.make(429, headers={"Retry-After": "0"})])
        with self.assertRaises(RateLimitExceeded):
            HTTPClient(config, session=session).get(BASE + "/page")

    def test_429_long_retry_after_stops_instead_of_ignoring(self):
        from requisicoes import RateLimitExceeded
        config = Config(base_url=BASE, page_id="123", interval=0, max_retry_wait=1)
        session = FakeSession([ResponseFactory.make(429, headers={"Retry-After": "99"})])
        with self.assertRaises(RateLimitExceeded):
            HTTPClient(config, session=session).get(BASE + "/page")
        self.assertEqual(len(session.calls), 1)


if __name__ == "__main__":
    unittest.main()
