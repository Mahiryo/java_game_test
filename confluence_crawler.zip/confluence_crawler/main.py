"""Início: carrega o .env e executa HTML -> análise -> PDF -> Swagger JSON."""
from __future__ import annotations

import argparse
import logging
import sys
from dataclasses import replace
from pathlib import Path

from config import load_config
from confluence_urls import page_id_from_value
from controle import executar


def main() -> int:
    parser = argparse.ArgumentParser(description="Crawler de documentação Confluence")
    parser.add_argument("--page-id", help="ID numérico ou URL da página inicial (sobrescreve .env)")
    parser.add_argument("--base-url", help="URL base do Confluence (sobrescreve .env)")
    parser.add_argument("--html-mode", choices=["auto", "html", "dc", "cloud"])
    parser.add_argument("--max-pages", type=int)
    parser.add_argument("--max-depth", type=int)
    parser.add_argument("--max-requests", type=int)
    parser.add_argument("--delay", type=float, help="Intervalo mínimo entre requisições em segundos")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--no-pdf", action="store_true", help="Pular exportação de PDFs")
    parser.add_argument("--no-json", action="store_true", help="Pular download dos JSON")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    try:
        config = load_config()
        overrides = {}
        if args.page_id is not None:
            overrides["page_id"] = page_id_from_value(args.page_id) or args.page_id
        for arg, field in [
            ("base_url", "base_url"), ("html_mode", "html_mode"),
            ("max_pages", "max_pages"), ("max_depth", "max_depth"),
            ("max_requests", "max_requests"), ("output_dir", "output_dir"),
        ]:
            value = getattr(args, arg)
            if value is not None:
                overrides[field] = value
        if args.delay is not None:
            overrides["interval"] = args.delay
        if args.no_pdf:
            overrides["export_pdf"] = False
        if args.no_json:
            overrides["download_json"] = False
        config = replace(config, **overrides)
        config.validate()
        report = executar(config)
        print(f"Páginas: {report['total_paginas']} | Requisições: {report['total_requisicoes']} | Fim: {report['parada']}")
        return 0 if report["parada"] == "fila esgotada" else 2
    except (ValueError, OSError) as exc:
        print(f"Configuração inválida: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
