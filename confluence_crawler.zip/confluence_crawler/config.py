"""Carregamento centralizado de configurações do crawler."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

from confluence_urls import page_id_from_value


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "sim", "on"}


@dataclass(frozen=True)
class Config:
    base_url: str
    page_id: str
    pat: str = ""
    email: str = ""
    api_token: str = ""
    cookie: str = ""
    html_mode: str = "auto"
    interval: float = 3.0
    timeout: float = 33.0
    max_pages: int = 30
    max_depth: int = 3
    max_requests: int = 100
    max_retries: int = 2
    max_pdf_polls: int = 8
    max_retry_wait: float = 120.0
    max_redirects: int = 5
    output_dir: Path = Path("output")
    export_pdf: bool = True
    download_json: bool = True
    strict_swagger: bool = True
    follow_all_on_api_page: bool = False
    allow_external_pdf_url: bool = True

    def validate(self) -> None:
        url = urlparse(self.base_url)
        if url.scheme not in {"http", "https"} or not url.netloc or url.username or url.password:
            raise ValueError("CONFLUENCE_BASE_URL deve ser uma URL HTTP(S) válida, sem credenciais.")
        if not self.page_id.isdigit():
            raise ValueError("CONFLUENCE_PAGE_ID deve ser um ID numérico ou URL com pageId.")
        if self.html_mode not in {"auto", "html", "dc", "cloud"}:
            raise ValueError("HTML_MODE deve ser auto, html, dc ou cloud.")
        for name in ("max_pages", "max_requests", "max_pdf_polls", "max_redirects"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} deve ser no mínimo 1.")
        if self.max_depth < 0 or self.max_retries < 0:
            raise ValueError("max_depth e max_retries não podem ser negativos.")
        if self.interval < 0 or self.timeout <= 0 or self.max_retry_wait < 0:
            raise ValueError("Intervalo, timeout e tempo de retry inválidos.")


def load_config() -> Config:
    load_dotenv()
    raw_id = os.getenv("CONFLUENCE_PAGE_ID", "").strip()
    page_id = page_id_from_value(raw_id) or raw_id
    config = Config(
        base_url=os.getenv("CONFLUENCE_BASE_URL", "").strip().rstrip("/"),
        page_id=page_id,
        pat=os.getenv("CONFLUENCE_PAT", "").strip(),
        email=os.getenv("CONFLUENCE_EMAIL", "").strip(),
        api_token=os.getenv("CONFLUENCE_API_TOKEN", "").strip(),
        cookie=os.getenv("CONFLUENCE_COOKIE", "").strip(),
        html_mode=os.getenv("HTML_MODE", "auto").strip().lower(),
        interval=float(os.getenv("REQUEST_INTERVAL", "3")),
        timeout=float(os.getenv("REQUEST_TIMEOUT", "33")),
        max_pages=int(os.getenv("MAX_PAGES", "30")),
        max_depth=int(os.getenv("MAX_DEPTH", "3")),
        max_requests=int(os.getenv("MAX_REQUESTS", "100")),
        max_retries=int(os.getenv("MAX_RETRIES", "2")),
        max_pdf_polls=int(os.getenv("MAX_PDF_POLLS", "8")),
        max_retry_wait=float(os.getenv("MAX_RETRY_WAIT", "120")),
        max_redirects=int(os.getenv("MAX_REDIRECTS", "5")),
        output_dir=Path(os.getenv("OUTPUT_DIR", "output")),
        export_pdf=_bool("EXPORT_PDF", True),
        download_json=_bool("DOWNLOAD_JSON", True),
        strict_swagger=_bool("STRICT_SWAGGER", True),
        follow_all_on_api_page=_bool("FOLLOW_ALL_ON_API_PAGE"),
        allow_external_pdf_url=_bool("ALLOW_EXTERNAL_PDF_URL", True),
    )
    return config
