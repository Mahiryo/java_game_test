"""Terceira requisição: baixar anexos JSON e validar OpenAPI/Swagger."""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import unquote, urlparse

from analisar_html import JsonAttachment
from config import Config
from requisicoes import HTTPClient


def _safe_filename(filename: str) -> str:
    filename = unquote(filename).replace("\\", "/").rsplit("/", 1)[-1]
    filename = re.sub(r"[^\w.\- ]+", "_", filename, flags=re.UNICODE).strip(" .")
    if not filename.lower().endswith(".json"):
        filename += ".json"
    if not filename:
        return "swagger.json"
    return filename[:135] + ".json" if len(filename) > 140 else filename


def _is_swagger(data: object) -> bool:
    if not isinstance(data, dict):
        return False
    return (
        isinstance(data.get("swagger"), str)
        or isinstance(data.get("openapi"), str)
        or (isinstance(data.get("paths"), dict) and isinstance(data.get("info"), dict))
    )


def extrair_json(
    client: HTTPClient, config: Config, attachment: JsonAttachment, page_id: str
) -> Path:
    raw = client.get(attachment.url, accept="application/json,application/octet-stream,*/*")
    try:
        decoded = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Anexo não é JSON válido ({attachment.name})") from exc
    if config.strict_swagger and not _is_swagger(decoded):
        raise ValueError(f"Anexo JSON sem estrutura Swagger/OpenAPI ({attachment.name})")
    output_dir = config.output_dir / "json" / page_id
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_name = attachment.name or unquote(urlparse(attachment.url).path.rsplit("/", 1)[-1])
    filename = _safe_filename(raw_name)
    path = output_dir / filename
    # Evita sobrescrever anexos diferentes que têm nomes iguais.
    if path.exists():
        stem = path.stem
        suffix = (attachment.resource_id or "novo")[:24]
        path = output_dir / f"{stem}_{suffix}.json"
        index = 2
        while path.exists():
            path = output_dir / f"{stem}_{suffix}_{index}.json"
            index += 1
    # Mantém os dados originais, após validar JSON.
    path.write_bytes(raw)
    return path
