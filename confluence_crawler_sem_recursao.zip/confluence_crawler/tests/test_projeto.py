"""Testes de contrato: não navega em filhos, limita chamadas e gera arquivos."""
from __future__ import annotations

import csv
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import requests

from analisar_html import analisar_html
from buscar_paginas import selecionar_candidatas
from config import Config
from confluence_urls import page_id_from_value, resolve_url
from controle import executar
from extrair_json import _is_swagger
from extrair_pdf import extrair_pdf
from requisicoes import (
    AuthenticationRequired, HTTPClient, OperationLimitExceeded, RateLimitExceeded,
    RequestBudgetExceeded, RequestFailed,
)

FIXTURES = Path(__file__).parent / "fixtures"
BASE = "https://confluence.exemplo.com"
ROOT_ID = "740220471"
ROOT_HTML = (FIXTURES / "pagina_raiz.html").read_bytes()
SWAGGER = json.dumps({"openapi": "3.0.1", "info": {"title": "API"}, "paths": {}}).encode()


class FakeClient:
    def __init__(self, pdf=b"%PDF-1.5\nfixture", json_data=SWAGGER):
        self.count = 0
        self.urls = []
        self.closed = False
        self.pdf = pdf
        self.json_data = json_data

    def get(self, url, **kwargs):
        self.urls.append(url)
        self.count += 1
        if "viewpage.action" in url:
            if "pageId=740220471" not in url:
                raise AssertionError("Uma página candidata foi visitada!")
            return ROOT_HTML
        if "pdfpageexport.action" in url:
            return self.pdf
        if ".json" in url:
            return self.json_data
        raise AssertionError(f"URL inesperada: {url}")

    def close(self):
        self.closed = True


class ParseTests(unittest.TestCase):
    def test_parsing_ids_classes_dedupe_and_attachment(self):
        result = analisar_html(ROOT_HTML.decode(), BASE, ROOT_ID)
        self.assertEqual(result.title, "Documentação Técnica")
        self.assertEqual({x.page_id for x in result.links}, {"777", "888", "999"})
        children = selecionar_candidatas(result, 100)
        self.assertEqual({x.page_id for x in children}, {"777", "888"})
        self.assertEqual(result.attachments[0].resource_id, "774212507")
        self.assertIn("swagger api-customer-information-v1.json", result.attachments[0].name)
        self.assertEqual(len([x for x in result.links if x.page_id == "777"]), 1)

    def test_api_link_dedup_prefers_descriptive(self):
        html = """<div id='main-content'>
        <a href='/pages/viewpage.action?pageId=45'>página genérica</a>
        <a href='/pages/viewpage.action?pageId=45' class='childpages-macro'>MS - Pagamentos</a>
        <a href='/pages/viewpage.action?pageId=99'>sem relação</a>
        </div>"""
        result = analisar_html(html, BASE, "1")
        chosen = selecionar_candidatas(result, 1)
        self.assertEqual([x.page_id for x in chosen], ["45"])
        self.assertEqual(chosen[0].title, "MS - Pagamentos")

    def test_children_macro_data_attribute(self):
        html = """<div id='main-content'><div data-macro-name='children'>
                 <a href='/pages/viewpage.action?pageId=81'>Rotas</a></div></div>"""
        selected = selecionar_candidatas(analisar_html(html, BASE, "123"), 100)
        self.assertEqual([x.page_id for x in selected], ["81"])

    def test_resource_id_page_without_pageid_in_href(self):
        html = """<div id='main-content'><a href='/display/ABC/APID' data-linked-resource-type='page'
             data-linked-resource-id='456'>Técnico</a></div>"""
        result = analisar_html(html, BASE, "123")
        self.assertEqual(result.links[0].page_id, "456")

    def test_urls_and_swagger(self):
        self.assertEqual(page_id_from_value("/pages/viewpage.action?pageId=123"), "123")
        self.assertEqual(page_id_from_value("https://site/wiki/pages/456/Page"), "456")
        self.assertIsNone(page_id_from_value("/display/ABC/Name"))
        self.assertEqual(resolve_url("https://site/wiki", "/download/attachments/1/a.json"),
                         "https://site/wiki/download/attachments/1/a.json")
        self.assertTrue(_is_swagger({"openapi": "3.0.3"}))
        self.assertFalse(_is_swagger({"other": "json"}))


class ExecutionTests(unittest.TestCase):
    def config(self, td: str, **kwargs) -> Config:
        return Config(base_url=BASE, page_id=ROOT_ID, output_dir=Path(td), **kwargs)

    def test_exactly_one_page_three_requests(self):
        with tempfile.TemporaryDirectory() as td:
            client = FakeClient()
            report = executar(self.config(td), client)
            self.assertEqual(report["total_requisicoes"], 3)
            self.assertEqual(report["paginas_visitadas"], [ROOT_ID])
            self.assertEqual(report["total_candidatas"], 2)
            self.assertEqual(report["parada"], "concluido")
            self.assertTrue(client.closed)
            self.assertTrue((Path(td) / "html" / f"{ROOT_ID}.html").exists())
            self.assertTrue((Path(td) / "pdf" / f"{ROOT_ID}.pdf").exists())
            self.assertTrue((Path(td) / "json" / ROOT_ID / "swagger api-customer-information-v1.json").exists())
            with (Path(td) / "candidatas.csv").open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file, delimiter=";"))
            self.assertEqual({r["pagina_candidata_id"] for r in rows}, {"777", "888"})
            self.assertTrue(all(x["status"] == "candidata_nao_visitada" for x in rows))
            self.assertTrue(all("pageId=777" not in url and "pageId=888" not in url for url in client.urls))
            self.assertTrue((Path(td) / "relatorio.json").exists())

    def test_html_only_one_request(self):
        with tempfile.TemporaryDirectory() as td:
            client = FakeClient()
            report = executar(self.config(td, export_pdf=False, download_json=False), client)
            self.assertEqual(report["total_requisicoes"], 1)
            self.assertEqual(report["total_candidatas"], 2)
            self.assertEqual(len(client.urls), 1)

    def test_pdf_error_does_not_block_json(self):
        with tempfile.TemporaryDirectory() as td:
            client = FakeClient(pdf=b"<html>PDF indisponivel</html>")
            report = executar(self.config(td), client)
            self.assertEqual(report["parada"], "concluido_com_erros")
            self.assertEqual(report["total_requisicoes"], 3)
            self.assertEqual(len(report["pagina"]["json"]), 1)

    def test_candidates_count_limited_no_crawl(self):
        with tempfile.TemporaryDirectory() as td:
            client = FakeClient()
            report = executar(self.config(td, max_candidates=1, export_pdf=False, download_json=False), client)
            self.assertEqual(report["total_candidatas"], 1)
            self.assertEqual(report["candidatas_descartadas_por_limite"], 1)
            self.assertEqual(report["total_requisicoes"], 1)

    def test_repeated_export_overwrites_json_instead_of_creating_copies(self):
        with tempfile.TemporaryDirectory() as td:
            for _ in range(3):
                executar(self.config(td), FakeClient())
            json_paths = list((Path(td) / "json" / ROOT_ID).glob("*.json"))
            self.assertEqual(len(json_paths), 1)

    def test_json_limit_zero(self):
        with tempfile.TemporaryDirectory() as td:
            client = FakeClient()
            report = executar(self.config(td, max_json_files=0), client)
            self.assertEqual(report["total_requisicoes"], 2)
            self.assertEqual(report["pagina"]["json"], [])

    def test_invalid_config_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                executar(self.config(td, interval=2.0), FakeClient())
            with self.assertRaises(ValueError):
                executar(self.config(td, max_attempts=4), FakeClient())


class ResponseFactory:
    @staticmethod
    def make(code, content=b"ok", headers=None):
        response = requests.Response()
        response.status_code = code
        response._content = content
        response.raw = io.BytesIO(content)
        response.headers.update(headers or {})
        return response


class FakeSession:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return next(self.responses)

    def close(self):
        pass


class HTTPTests(unittest.TestCase):
    def test_429_retry_two_then_success_three_total(self):
        config = Config(base_url=BASE, page_id="123")
        session = FakeSession([
            ResponseFactory.make(429, headers={"Retry-After": "0"}),
            ResponseFactory.make(503),
            ResponseFactory.make(200, b"done"),
        ])
        client = HTTPClient(config, session=session)
        with patch("requisicoes.time.sleep") as sleep:
            with client.operation("HTML"):
                self.assertEqual(client.get(BASE + "/page"), b"done")
        self.assertEqual(client.count, 3)
        self.assertGreaterEqual(sleep.call_count, 2)
        self.assertTrue(all(call.args[0] > 0 for call in sleep.call_args_list))

    def test_429_stops_after_three(self):
        config = Config(base_url=BASE, page_id="123")
        session = FakeSession([ResponseFactory.make(429) for _ in range(3)])
        client = HTTPClient(config, session=session)
        with patch("requisicoes.time.sleep"):
            with self.assertRaises(RateLimitExceeded):
                with client.operation("PDF"):
                    client.get(BASE + "/pdf")
        self.assertEqual(client.count, 3)

    def test_retry_after_too_long_no_second_call(self):
        config = Config(base_url=BASE, page_id="123", max_retry_wait=5)
        session = FakeSession([ResponseFactory.make(429, headers={"Retry-After": "999"})])
        with self.assertRaises(RateLimitExceeded):
            HTTPClient(config, session=session).get(BASE + "/page")
        self.assertEqual(len(session.calls), 1)

    def test_operation_limit_shared_across_three_gets(self):
        config = Config(base_url=BASE, page_id="123")
        session = FakeSession([ResponseFactory.make(200) for _ in range(3)])
        client = HTTPClient(config, session=session)
        with patch("requisicoes.time.sleep"):
            with self.assertRaises(OperationLimitExceeded):
                with client.operation("PDF"):
                    for _ in range(4):
                        client.get(BASE + "/progress")
        self.assertEqual(client.count, 3)

    def test_global_limit(self):
        config = Config(base_url=BASE, page_id="123", max_requests=2)
        client = HTTPClient(config, session=FakeSession([ResponseFactory.make(200)] * 2))
        with patch("requisicoes.time.sleep"):
            client.get(BASE + "/a")
            client.get(BASE + "/b")
            with self.assertRaises(RequestBudgetExceeded):
                client.get(BASE + "/c")
        self.assertEqual(client.count, 2)

    def test_redirect_cycle_blocked(self):
        config = Config(base_url=BASE, page_id="123")
        session = FakeSession([
            ResponseFactory.make(302, headers={"Location": "/a"}),
        ])
        client = HTTPClient(config, session=session)
        with self.assertRaises(RequestFailed):
            client.get(BASE + "/a")
        self.assertEqual(client.count, 1)

    def test_external_redirect_auth_not_forwarded(self):
        config = Config(base_url=BASE, page_id="123", pat="secret", cookie="SESSION=abc")
        session = FakeSession([
            ResponseFactory.make(302, headers={"Location": "https://cdn.example.net/file.pdf"}),
            ResponseFactory.make(200, b"%PDF-1.7\n"),
        ])
        client = HTTPClient(config, session=session)
        with patch("requisicoes.time.sleep"):
            with client.operation("PDF"):
                client.get(BASE + "/pdf", allow_external=True)
        self.assertIn("Authorization", session.calls[0][1]["headers"])
        self.assertNotIn("Authorization", session.calls[1][1]["headers"])
        self.assertNotIn("Cookie", session.calls[1][1]["headers"])
        self.assertEqual(client.count, 2)

    def test_auth_failfast(self):
        session = FakeSession([ResponseFactory.make(401)])
        client = HTTPClient(Config(base_url=BASE, page_id="123"), session=session)
        with self.assertRaises(AuthenticationRequired):
            client.get(BASE + "/page")
        self.assertEqual(client.count, 1)

    def test_content_size_limit(self):
        config = Config(base_url=BASE, page_id="123", max_download_bytes=1024)
        session = FakeSession([ResponseFactory.make(200, b"x" * 2000)])
        client = HTTPClient(config, session=session)
        with self.assertRaises(RequestFailed):
            client.get(BASE + "/page")
        self.assertEqual(client.count, 1)

    def test_external_json_forbidden(self):
        config = Config(base_url=BASE, page_id="123")
        with self.assertRaises(RequestFailed):
            HTTPClient(config, session=FakeSession([])).get("https://evil.example/swagger.json")


class PDFTests(unittest.TestCase):
    def test_async_pdf_in_three_calls(self):
        class PdfClient:
            def __init__(self):
                self.responses = iter([
                    b'<html><meta content="taskabc" name="ajs-taskId"></html>',
                    b'{"state":"COMPLETE", "result":"/download/exports/taskabc.pdf"}',
                    b'%PDF-1.7\nfixture',
                ])
                self.calls = []

            def get(self, url, **kwargs):
                self.calls.append(url)
                return next(self.responses)

        with tempfile.TemporaryDirectory() as td:
            fake = PdfClient()
            config = Config(base_url=BASE, page_id="123", output_dir=Path(td))
            path = extrair_pdf(fake, config, "123", Path(td) / "pdf/123.pdf")
            self.assertTrue(path.read_bytes().startswith(b"%PDF-"))
            self.assertEqual(len(fake.calls), 3)

    def test_async_pdf_not_ready_stops_without_loop(self):
        class PdfClient:
            def __init__(self):
                self.count = 0

            def get(self, url, **kwargs):
                self.count += 1
                return (b'<html><meta content="a" name="ajs-taskId"></html>' if self.count == 1
                        else b'{"state":"RUNNING"}')

        with tempfile.TemporaryDirectory() as td:
            fake = PdfClient()
            config = Config(base_url=BASE, page_id="123", output_dir=Path(td))
            with self.assertRaises(TimeoutError):
                extrair_pdf(fake, config, "123", Path(td) / "123.pdf")
            self.assertEqual(fake.count, 2)


if __name__ == "__main__":
    unittest.main()
