"""Uma sessão, contador global, 3 segundos e até 3 chamadas por artefato.

Uma 'operação' é extrair HTML, PDF ou um JSON específico. Redirecionamentos,
retries, API fallback e polling contam na mesma cota da operação.
"""
from __future__ import annotations

import base64
import email.utils
import logging
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests

from config import Config
from confluence_urls import same_origin

LOG = logging.getLogger(__name__)


class RequestBudgetExceeded(RuntimeError):
    """Limite global de requisições esgotado."""


class OperationLimitExceeded(RuntimeError):
    """Limite de requisições desta extração (HTML, PDF, JSON) esgotado."""


class RequestFailed(RuntimeError):
    pass


class AuthenticationRequired(RequestFailed):
    pass


class RateLimitExceeded(RequestFailed):
    pass


class HTTPClient:
    def __init__(self, config: Config, session: requests.Session | None = None):
        self.config = config
        self.session = session or requests.Session()
        self.count = 0
        self.last_finished: float | None = None
        self._operation_calls: int | None = None
        self._operation_name = ""

    @contextmanager
    def operation(self, name: str):
        if self._operation_calls is not None:
            raise RuntimeError("Operações HTTP simultâneas/aninhadas são proibidas")
        self._operation_calls = 0
        self._operation_name = name
        try:
            yield
        finally:
            self._operation_calls = None
            self._operation_name = ""

    def _headers(self, url: str, accept: str) -> dict[str, str]:
        headers = {"User-Agent": "ConfluenceSinglePageExporter/2.0", "Accept": accept}
        if same_origin(self.config.base_url, url):
            headers["X-Atlassian-Token"] = "no-check"
            if self.config.pat:
                headers["Authorization"] = f"Bearer {self.config.pat}"
            elif self.config.email and self.config.api_token:
                value = base64.b64encode(f"{self.config.email}:{self.config.api_token}".encode()).decode()
                headers["Authorization"] = f"Basic {value}"
            if self.config.cookie:
                headers["Cookie"] = self.config.cookie
        return headers

    def _pace(self) -> None:
        if self.count >= self.config.max_requests:
            raise RequestBudgetExceeded(f"Limite global de {self.config.max_requests} chamadas atingido")
        if self._operation_calls is not None and self._operation_calls >= self.config.max_attempts:
            raise OperationLimitExceeded(
                f"{self._operation_name}: limite de {self.config.max_attempts} chamadas atingido"
            )
        if self.last_finished is not None:
            wait = self.config.interval - (time.monotonic() - self.last_finished)
            if wait > 0:
                time.sleep(wait)
        self.count += 1
        if self._operation_calls is not None:
            self._operation_calls += 1

    @staticmethod
    def _retry_after(response: requests.Response) -> float | None:
        header = response.headers.get("Retry-After", "").strip()
        if not header:
            return None
        try:
            return max(0.0, float(header))
        except ValueError:
            try:
                parsed = email.utils.parsedate_to_datetime(header)
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=timezone.utc)
                return max(0.0, (parsed - datetime.now(timezone.utc)).total_seconds())
            except (ValueError, TypeError, IndexError):
                return None

    def _read(self, response: requests.Response) -> bytes:
        max_bytes = self.config.max_download_bytes
        declared = response.headers.get("Content-Length", "")
        if declared.isdecimal() and int(declared) > max_bytes:
            raise RequestFailed(f"Arquivo excede MAX_DOWNLOAD_BYTES ({max_bytes} bytes)")
        pieces = []
        size = 0
        for chunk in response.iter_content(chunk_size=65_536):
            if not chunk:
                continue
            size += len(chunk)
            if size > max_bytes:
                raise RequestFailed(f"Arquivo excede MAX_DOWNLOAD_BYTES ({max_bytes} bytes)")
            pieces.append(chunk)
        return b"".join(pieces)

    def get(self, url: str, *, accept: str = "*/*", allow_external: bool = False) -> bytes:
        """GET sem follow_redirects automático; cada chamada real consome a cota."""
        original = urlparse(url)
        if original.scheme not in {"https", "http"} or not original.hostname:
            raise RequestFailed("URL HTTP(S) inválida")
        if not same_origin(self.config.base_url, url) and not allow_external:
            raise RequestFailed("URL externa bloqueada")

        current = url
        seen: set[str] = set()
        redirects = 0
        attempts = 0
        while True:
            target = urlparse(current)
            if target.scheme not in {"https", "http"} or not target.hostname:
                raise RequestFailed("Redirecionamento HTTP(S) inválido")
            if not same_origin(self.config.base_url, current) and not allow_external:
                raise RequestFailed("Redirecionamento para outro domínio bloqueado")
            self._pace()
            attempts += 1
            LOG.info("GET %s/%s: %s", self.count, self.config.max_requests, target.path)
            response = None
            error: Exception | None = None
            try:
                response = self.session.get(
                    current,
                    headers=self._headers(current, accept),
                    allow_redirects=False,
                    timeout=self.config.timeout,
                    stream=True,
                )
                status = response.status_code
                if status in {301, 302, 303, 307, 308}:
                    destination = urljoin(current, response.headers.get("Location", ""))
                    if (not response.headers.get("Location") or redirects >= self.config.max_redirects
                            or destination in seen or destination == current):
                        raise RequestFailed("Redirect sem destino, em loop ou acima do limite")
                    seen.add(current)
                    current = destination
                    redirects += 1
                    continue
                if status in {401, 403}:
                    raise AuthenticationRequired(f"HTTP {status}: autenticação ou permissão insuficiente")
                if status in {429, 500, 502, 503, 504}:
                    wait = self._retry_after(response) if status == 429 else None
                    if status == 429 and wait is not None and wait > self.config.max_retry_wait:
                        raise RateLimitExceeded(f"HTTP 429: Retry-After de {wait:.0f}s excede o limite de espera")
                    if attempts >= self.config.max_attempts:
                        if status == 429:
                            raise RateLimitExceeded("HTTP 429: limite de 3 chamadas; interrompido")
                        raise RequestFailed(f"HTTP {status}: limite de tentativas atingido")
                    # Somente erros temporários são reenviados. Não repetir 404/401/403.
                    LOG.warning("HTTP %s: tentativa %s/%s", status, attempts, self.config.max_attempts)
                    if wait and wait > self.config.interval:
                        time.sleep(min(wait - self.config.interval, self.config.max_retry_wait))
                    continue
                if status >= 400:
                    raise RequestFailed(f"HTTP {status} no recurso {target.path}")
                return self._read(response)
            except requests.RequestException as exc:
                error = exc
                if attempts >= self.config.max_attempts:
                    raise RequestFailed(f"Falha de rede: {type(exc).__name__}: {exc}") from exc
                LOG.warning("Falha temporária de conexão (%s): tentativa %s/%s", type(exc).__name__, attempts, self.config.max_attempts)
                continue
            finally:
                self.last_finished = time.monotonic()
                if response is not None:
                    response.close()

    def close(self) -> None:
        self.session.close()
