"""Configuração única, lida do .env (sem fazer requisições)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from confluence_urls import page_id_from_value


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "sim", "on"}


@dataclass(frozen=True)
class Config:
    base_url: str
    page_id: str
    pat: str = ""
    email: str = ""
    api_token: str = ""
    cookie: str = ""
    html_mode: str = "html"  # Um GET por padrão; 'auto' habilita fallback.
    interval: float = 3.0
    timeout: float = 30.0
    max_requests: int = 15                # Orçamento global de chamadas HTTP.
    max_attempts: int = 3                # Inclui retries, redirects e polling por artefato.
    max_redirects: int = 2
    max_pdf_polls: int = 1
    max_retry_wait: float = 30.0
    max_candidates: int = 300
    max_json_files: int = 10
    max_download_bytes: int = 25_000_000
    output_dir: Path = Path("output")
    export_pdf: bool = True
    download_json: bool = True
    strict_swagger: bool = False
    allow_external_pdf_url: bool = False

    def validate(self) -> None:
        parsed = urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
            raise ValueError("CONFLUENCE_BASE_URL deve ser uma URL HTTP(S) válida, sem credenciais.")
        if not self.page_id.isdigit():
            raise ValueError("CONFLUENCE_PAGE_ID deve ser numérico ou uma URL contendo pageId.")
        if self.html_mode not in {"html", "auto", "dc", "cloud"}:
            raise ValueError("HTML_MODE deve ser html, auto, dc ou cloud.")
        if self.interval < 3:
            raise ValueError("REQUEST_INTERVAL deve ser >= 3 segundos.")
        if not 1 <= self.max_attempts <= 3:
            raise ValueError("MAX_ATTEMPTS deve estar entre 1 e 3.")
        if not 0 <= self.max_redirects <= 2:
            raise ValueError("MAX_REDIRECTS deve estar entre 0 e 2.")
        if not 0 <= self.max_pdf_polls <= 1:
            raise ValueError("MAX_PDF_POLLS deve estar entre 0 e 1, para preservar o limite de chamadas.")
        if not 1 <= self.max_requests <= 100:
            raise ValueError("MAX_REQUESTS deve estar entre 1 e 100.")
        if not 1 <= self.max_candidates <= 5000:
            raise ValueError("MAX_CANDIDATES deve estar entre 1 e 5000.")
        if not 0 <= self.max_json_files <= 100:
            raise ValueError("MAX_JSON_FILES deve estar entre 0 e 100.")
        if self.timeout <= 0 or self.max_retry_wait < 0 or not 1024 <= self.max_download_bytes <= 100_000_000:
            raise ValueError("Timeout, espera ou limite de download inválido.")


def load_config() -> Config:
    load_dotenv()
    raw = os.getenv("CONFLUENCE_PAGE_ID", "").strip()
    return Config(
        base_url=os.getenv("CONFLUENCE_BASE_URL", "").strip().rstrip("/"),
        page_id=page_id_from_value(raw) or raw,
        pat=os.getenv("CONFLUENCE_PAT", "").strip(),
        email=os.getenv("CONFLUENCE_EMAIL", "").strip(),
        api_token=os.getenv("CONFLUENCE_API_TOKEN", "").strip(),
        cookie=os.getenv("CONFLUENCE_COOKIE", "").strip(),
        html_mode=os.getenv("HTML_MODE", "html").strip().lower(),
        interval=float(os.getenv("REQUEST_INTERVAL", "3")),
        timeout=float(os.getenv("REQUEST_TIMEOUT", "30")),
        max_requests=int(os.getenv("MAX_REQUESTS", "15")),
        max_attempts=int(os.getenv("MAX_ATTEMPTS", "3")),
        max_redirects=int(os.getenv("MAX_REDIRECTS", "2")),
        max_pdf_polls=int(os.getenv("MAX_PDF_POLLS", "1")),
        max_retry_wait=float(os.getenv("MAX_RETRY_WAIT", "30")),
        max_candidates=int(os.getenv("MAX_CANDIDATES", "300")),
        max_json_files=int(os.getenv("MAX_JSON_FILES", "10")),
        max_download_bytes=int(os.getenv("MAX_DOWNLOAD_BYTES", "25000000")),
        output_dir=Path(os.getenv("OUTPUT_DIR", "output")),
        export_pdf=_bool("EXPORT_PDF", True),
        download_json=_bool("DOWNLOAD_JSON", True),
        strict_swagger=_bool("STRICT_SWAGGER", False),
        allow_external_pdf_url=_bool("ALLOW_EXTERNAL_PDF_URL", False),
    )
