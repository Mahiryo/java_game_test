"""Classificação SOMENTE local: nenhuma página candidata é visitada."""
from __future__ import annotations

from analisar_html import PageAnalysis, PageLink


def selecionar_candidatas(analysis: PageAnalysis, limite: int) -> list[PageLink]:
    """Prioriza macro de filhos e nomes de API/métodos, sem abrir qualquer URL."""
    candidates = [
        link for link in analysis.links
        if link.child_reference or link.matched_api or link.matched_method
    ]
    candidates.sort(key=lambda item: (
        not item.child_reference,
        not item.matched_api,
        not item.matched_method,
        item.page_id,
    ))
    return candidates[:limite]


def motivos(link: PageLink) -> str:
    tags = []
    if link.child_reference:
        tags.append("classe/estrutura de filhos")
    if link.matched_api:
        tags.append("nome relacionado a API")
    if link.matched_method:
        tags.append("metodo HTTP")
    return "; ".join(tags)
