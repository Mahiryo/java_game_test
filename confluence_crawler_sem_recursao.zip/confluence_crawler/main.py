"""Execução da página-mãe SOMENTE; filhos são exportados como linhas de CSV."""
from __future__ import annotations

import argparse
import logging
import sys
from dataclasses import replace
from pathlib import Path

from config import load_config
from confluence_urls import page_id_from_value
from controle import executar


def main() -> int:
    parser = argparse.ArgumentParser(description="Exportar uma página Confluence e listar candidatas em CSV")
    parser.add_argument("--page-id", help="ID ou URL da página-mãe (sobrescreve o .env)")
    parser.add_argument("--base-url", help="Endereço base do Confluence")
    parser.add_argument("--html-mode", choices=["html", "auto", "dc", "cloud"])
    parser.add_argument("--max-requests", type=int)
    parser.add_argument("--max-attempts", type=int, help="Máximo 3 chamadas por artefato")
    parser.add_argument("--max-candidates", type=int)
    parser.add_argument("--max-json-files", type=int)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--no-pdf", action="store_true")
    parser.add_argument("--no-json", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s | %(levelname)s | %(message)s", datefmt="%H:%M:%S")
    try:
        config = load_config()
        changes = {}
        if args.page_id:
            changes["page_id"] = page_id_from_value(args.page_id) or args.page_id
        for option in ["base_url", "html_mode", "max_requests", "max_attempts", "max_candidates",
                       "max_json_files", "output_dir"]:
            value = getattr(args, option)
            if value is not None:
                changes[option] = value
        if args.no_pdf:
            changes["export_pdf"] = False
        if args.no_json:
            changes["download_json"] = False
        config = replace(config, **changes)
        config.validate()
        report = executar(config)
        print(f"Página-mãe: {config.page_id} | Candidatas: {report['total_candidatas']} | "
              f"Chamadas HTTP: {report['total_requisicoes']} | Situação: {report['parada']}")
        print(f"Arquivos em: {config.output_dir.resolve()}")
        return 0 if report["parada"] in {"concluido", "concluido_com_erros"} else 2
    except (ValueError, OSError) as exc:
        print(f"Configuração inválida: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
