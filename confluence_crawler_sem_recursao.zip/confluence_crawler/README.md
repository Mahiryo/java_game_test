# Exportador Confluence de página única

Acessa **somente a página-mãe** configurada, salva o HTML, tenta exportar o PDF e baixa os arquivos JSON mencionados no HTML, quando disponíveis. Extrai `href`, Page IDs e classes de possíveis páginas-filhas e **somente os registra no `candidatas.csv`**, sem visitar nem enfileirar esses links. Não existe busca por profundidade, fila BFS ou recursão.

## Instalação

Python 3.10+:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Configure o `.env`:

```ini
CONFLUENCE_BASE_URL=https://confluence.empresa.com
CONFLUENCE_PAGE_ID=740220471
CONFLUENCE_COOKIE=JSESSIONID=...; outro_cookie=...
HTML_MODE=html
REQUEST_INTERVAL=3
MAX_ATTEMPTS=3
MAX_REQUESTS=15
```

Também funciona com `CONFLUENCE_PAT` ou `CONFLUENCE_EMAIL` + `CONFLUENCE_API_TOKEN`. Para Confluence sob `/wiki` ou `/confluence`, mantenha o prefixo na `CONFLUENCE_BASE_URL`.

Execute:

```bash
python main.py
python main.py --page-id 740220471
python main.py --page-id 'https://site/pages/viewpage.action?pageId=740220471' --no-pdf
python main.py --max-requests 5 --max-json-files 1
```

## Saída

```text
output/
  html/740220471.html
  pdf/740220471.pdf                 # se suportado pela instância
  json/740220471/swagger-api.json   # se existir no HTML e retornar JSON válido
  candidatas.csv                     # ID, título, URL, critérios, classes, status
  relatorio.json                     # erros, totais e motivo de parada
```

CSV usa `;` como separador e UTF-8 com BOM (abre bem no Excel em PT-BR). É produzido inclusive se a extração falhar; seus registros sempre têm `status=candidata_nao_visitada`. Cada ID é único, o ID da mãe é descartado e só entram links do mesmo domínio reconhecidos por macro/classes de filhos ou nomes relacionados a API/métodos HTTP.

## Política de requisições

- **Um único GET HTML** como padrão (`HTML_MODE=html`). Apenas se configurar `auto`, há fallback para API Data Center e Cloud quando necessário.
- **Uma tentativa inicial de PDF** via FlyingPDF. Se vier uma tarefa assíncrona, até **uma** consulta de progresso e **um** download final, dentro do limite de 3. Se a tarefa não estiver concluída, o PDF é registrado como falha, sem polling interminável.
- **Um GET por JSON identificado**. URLs repetidas são removidas durante a análise; `MAX_JSON_FILES` limita os downloads.
- **Pelo menos 3 segundos entre o encerramento de um GET e o início do próximo**, inclusive retries, redirects, fallback e polling. Isso é centralizado em `requisicoes.py`; não há paralelismo.
- **No máximo 3 chamadas HTTP por artefato** (HTML, PDF ou cada JSON). Redirects, retries, fallback e polling contam. `MAX_ATTEMPTS` pode ser reduzido para 1 ou 2, mas nunca aumentado acima de 3.
- **Orçamento global** `MAX_REQUESTS=15` (alterável entre 1 e 100); não é uma meta de uso. Uma execução típica com um JSON e PDF direto usa **3 requisições**: HTML + PDF + JSON.
- Em HTTP `401/403`, `429` persistente ou orçamento global esgotado, a execução para. `Retry-After` é respeitado até `MAX_RETRY_WAIT` e não é burlado.
- **Sem loops de navegação**: a lista de páginas do HTML nunca é requisitada. URLs de redirecionamento repetidas são bloqueadas, máximo 2 redirects, limite de bytes por download e deduplicação de anexos.

`STRICT_SWAGGER=false` salva qualquer anexo `.json` válido; `true` exige estrutura Swagger/OpenAPI. `ALLOW_EXTERNAL_PDF_URL=false` impede acesso a outro domínio por padrão. Se sua instância usa exportação PDF hospedada fora do domínio (ex. Cloud), você pode habilitar redirecionamentos externos para PDF, mas credenciais não serão enviadas para outro domínio.

Não é possível garantir que o servidor não responda com **HTTP 429**. O script respeita os limites definidos pelo servidor e interrompe ao esgotar as tentativas.

## Arquivos do projeto

| Arquivo | Responsabilidade |
|---|---|
| `main.py` | parâmetros e execução |
| `config.py` | `.env` e validação de limites |
| `requisicoes.py` | rate limiting, retries, redirecionamentos, orçamento |
| `extrair_html.py` | leitura da página mãe |
| `analisar_html.py` | leitura local de links, classes e JSON |
| `buscar_paginas.py` | classificação local dos candidatos; **não navega** |
| `extrair_pdf.py` | FlyingPDF, no máximo uma consulta de progresso |
| `extrair_json.py` | validação e gravação dos JSON |
| `controle.py` | execução sequencial e CSV/relatório |

## Testes sem rede

```bash
python -m unittest discover -s tests -v
```
