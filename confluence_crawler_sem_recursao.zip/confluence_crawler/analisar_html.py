"""Análise OFFLINE da página-mãe: hrefs, classes e anexos JSON conhecidos."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlparse

from bs4 import BeautifulSoup, Tag
from confluence_urls import page_id_from_value, resolve_url, same_origin

API_TITLE_RE = re.compile(
    r"\bms\b|micro[\s_-]*servi[cç]o|microsservi[cç]o|\bt[eé]cnic[oa]s?\b|\bapid\b|"
    r"\bopenapi\b|\bswagger\b|documenta[cç][aã]o\s+(?:da\s+)?api|\bapi\b",
    re.IGNORECASE,
)
METHOD_RE = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b", re.IGNORECASE)
CHILD_CLASS_RE = re.compile(r"childpages|child-page|pagetree|children|childpages-macro", re.IGNORECASE)
CONTENT_SELECTORS = ["#main-content", ".wiki-content", ".ak-renderer-document", "#content", "main"]


@dataclass(frozen=True)
class PageLink:
    page_id: str
    title: str
    url: str
    matched_api: bool
    matched_method: bool
    child_reference: bool
    source_classes: str = ""


@dataclass(frozen=True)
class JsonAttachment:
    name: str
    url: str
    resource_id: str = ""


@dataclass
class PageAnalysis:
    title: str
    links: list[PageLink] = field(default_factory=list)
    attachments: list[JsonAttachment] = field(default_factory=list)


def _content_root(soup: BeautifulSoup) -> Tag | BeautifulSoup:
    for selector in CONTENT_SELECTORS:
        root = soup.select_one(selector)
        if root:
            return root
    return soup


def _classes(anchor: Tag) -> str:
    classes: list[str] = []
    for el in [anchor, *anchor.parents]:
        if not isinstance(el, Tag) or el.name in {"html", "body"}:
            break
        for value in el.get("class", []):
            if value not in classes:
                classes.append(value)
        if len(classes) >= 12:
            break
    return " ".join(classes[:12])


def _child_reference(anchor: Tag) -> bool:
    if anchor.get("data-linked-resource-type") == "page":
        return True
    if CHILD_CLASS_RE.search(_classes(anchor)):
        return True
    for el in [anchor, *anchor.parents]:
        if not isinstance(el, Tag) or el.name in {"html", "body"}:
            break
        if CHILD_CLASS_RE.search(str(el.get("data-macro-name", ""))):
            return True
    return False


def _is_attachment_candidate(anchor: Tag) -> bool:
    href = anchor.get("href", "") or ""
    src = anchor.get("data-file-src", "") or ""
    return (
        "confluence-embedded-file" in anchor.get("class", [])
        or anchor.get("data-linked-resource-type") == "attachment"
        or anchor.get("data-mime-type", "").lower() == "application/json"
        or "/download/attachments/" in href
        or "/download/attachments/" in src
        or (".json" in href.lower() and bool(re.search(r"swagger|openapi", href, re.I)))
    )


def analisar_html(html: str, base_url: str, page_id: str) -> PageAnalysis:
    soup = BeautifulSoup(html, "html.parser")
    root = _content_root(soup)
    heading = soup.select_one("h1.pagetitle, h1#title-text, #title-heading, h1")
    title = heading.get_text(" ", strip=True) if heading else f"Página {page_id}"
    result = PageAnalysis(title=title)
    links: dict[str, PageLink] = {}
    attachments_seen: set[str] = set()

    for anchor in root.select("a[href], a[data-file-src], a[data-linked-resource-id]"):
        if anchor.find_parent("nav"):
            continue
        href = (anchor.get("href") or "").strip()
        src = (anchor.get("data-file-src") or "").strip()
        is_attachment = _is_attachment_candidate(anchor)
        raw_url = (href if "/download/attachments/" in href else (src or href)) if is_attachment else href
        if not raw_url or raw_url.lower().startswith(("#", "javascript:", "mailto:", "data:")):
            continue
        link_url = resolve_url(base_url, raw_url)
        if not same_origin(base_url, link_url):
            continue

        if is_attachment:
            label = (
                anchor.get("data-linked-resource-default-alias")
                or anchor.get("aria-label")
                or anchor.get("title")
                or unquote(urlparse(link_url).path.rsplit("/", 1)[-1])
            ).strip()
            names = " ".join((label, unquote(urlparse(link_url).path), src))
            if re.search(r"\.json(?:\b|$|\?)", names, re.I) or anchor.get("data-mime-type", "").lower() == "application/json":
                resource_id = (anchor.get("data-linked-resource-id") or "").strip()
                dedupe = resource_id or unquote(urlparse(link_url).path)
                if dedupe not in attachments_seen:
                    attachments_seen.add(dedupe)
                    result.attachments.append(JsonAttachment(label, link_url, resource_id))
            continue

        found_id = page_id_from_value(link_url)
        if not found_id and anchor.get("data-linked-resource-type") == "page":
            potential_id = str(anchor.get("data-linked-resource-id") or "")
            found_id = potential_id if potential_id.isdigit() else None
        if not found_id or found_id == page_id:
            continue
        text = (
            anchor.get_text(" ", strip=True)
            or anchor.get("aria-label")
            or anchor.get("title")
            or f"Página {found_id}"
        ).strip()
        new = PageLink(
            page_id=found_id,
            title=text,
            url=link_url,
            matched_api=bool(API_TITLE_RE.search(text)),
            matched_method=bool(METHOD_RE.search(text)),
            child_reference=_child_reference(anchor),
            source_classes=_classes(anchor),
        )
        old = links.get(found_id)
        # Um link genérico não deve esconder outro link mais descritivo para o mesmo ID.
        rank = lambda x: (int(x.child_reference), int(x.matched_api), int(x.matched_method), len(x.title))
        if old is None or rank(new) > rank(old):
            links[found_id] = new
    result.links = list(links.values())
    return result
