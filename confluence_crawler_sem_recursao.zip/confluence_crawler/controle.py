"""Executa SOMENTE a mãe e registra links candidatos sem acessá-los."""
from __future__ import annotations

import csv
import json
import logging
from contextlib import nullcontext
from datetime import datetime, timezone
from pathlib import Path

from analisar_html import analisar_html
from buscar_paginas import motivos, selecionar_candidatas
from config import Config
from extrair_html import extrair_html
from extrair_json import extrair_json
from extrair_pdf import extrair_pdf
from requisicoes import (
    AuthenticationRequired, HTTPClient, RateLimitExceeded, RequestBudgetExceeded,
)

LOG = logging.getLogger(__name__)
CSV_COLUMNS = ["pagina_mae_id", "pagina_candidata_id", "titulo", "url", "criterios", "classes_html", "status"]


def _csv_safe(value: str) -> str:
    """Neutraliza fórmulas de planilha originadas de títulos HTML não confiáveis."""
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


def _operation(client: HTTPClient, name: str):
    # Ajuda testes locais com clientes falsos; HTTPClient real sempre impõe o limite.
    return client.operation(name) if hasattr(client, "operation") else nullcontext()


def _registrar_csv(destino: Path, parent_id: str, links: list) -> None:
    destino.parent.mkdir(parents=True, exist_ok=True)
    with destino.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=CSV_COLUMNS, delimiter=";")
        writer.writeheader()
        for link in links:
            writer.writerow({
                "pagina_mae_id": parent_id,
                "pagina_candidata_id": link.page_id,
                "titulo": _csv_safe(link.title),
                "url": link.url,
                "criterios": motivos(link),
                "classes_html": _csv_safe(link.source_classes),
                "status": "candidata_nao_visitada",
            })


def executar(config: Config, client: HTTPClient | None = None) -> dict:
    config.validate()
    client = client or HTTPClient(config)
    config.output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = config.output_dir / "candidatas.csv"
    _registrar_csv(csv_path, config.page_id, [])

    item = {
        "id": config.page_id,
        "titulo": None,
        "html": None,
        "pdf": None,
        "json": [],
        "anexos_json_encontrados": 0,
        "erros": [],
    }
    report = {
        "inicio": datetime.now(timezone.utc).isoformat(),
        "pagina_mae": config.page_id,
        "paginas_visitadas": [config.page_id],
        "links_candidatos_csv": str(csv_path),
        "total_candidatas": 0,
        "candidatas_descartadas_por_limite": 0,
        "total_requisicoes": 0,
        "limites": {
            "max_requests": config.max_requests,
            "max_attempts_por_artefato": config.max_attempts,
            "interval_seconds": config.interval,
            "max_json_files": config.max_json_files,
            "max_candidates": config.max_candidates,
        },
        "pagina": item,
        "parada": "concluido",
    }
    analysis = None

    def capturar_erro(label: str, exc: Exception) -> bool:
        item["erros"].append(f"{label}: {exc}")
        LOG.warning("%s: %s", label, exc)
        if isinstance(exc, RequestBudgetExceeded):
            report["parada"] = "limite_global_de_requisicoes"
            return True
        if isinstance(exc, RateLimitExceeded):
            report["parada"] = "bloqueio_http_429"
            return True
        if isinstance(exc, AuthenticationRequired):
            report["parada"] = "sem_permissao"
            return True
        return False

    try:
        try:
            with _operation(client, "HTML"):
                html = extrair_html(client, config, config.page_id)
            path = config.output_dir / "html" / f"{config.page_id}.html"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(html, encoding="utf-8")
            item["html"] = str(path)
            analysis = analisar_html(html, config.base_url, config.page_id)
            item["titulo"] = analysis.title
            links = selecionar_candidatas(analysis, config.max_candidates)
            report["total_candidatas"] = len(links)
            report["candidatas_descartadas_por_limite"] = max(0, len([
                link for link in analysis.links
                if link.child_reference or link.matched_api or link.matched_method
            ]) - len(links))
            _registrar_csv(csv_path, config.page_id, links)
            item["anexos_json_encontrados"] = len(analysis.attachments)
        except Exception as exc:
            if capturar_erro("HTML", exc):
                return report

        if config.export_pdf:
            try:
                with _operation(client, "PDF"):
                    path = config.output_dir / "pdf" / f"{config.page_id}.pdf"
                    item["pdf"] = str(extrair_pdf(client, config, config.page_id, path))
            except Exception as exc:
                if capturar_erro("PDF", exc):
                    return report

        if analysis and config.download_json:
            used_names: set[str] = set()
            for attachment in analysis.attachments[:config.max_json_files]:
                try:
                    with _operation(client, f"JSON {attachment.name}"):
                        path = extrair_json(client, config, attachment, config.page_id, used_names=used_names)
                    item["json"].append(str(path))
                except Exception as exc:
                    if capturar_erro(f"JSON {attachment.name}", exc):
                        return report

        if item["erros"]:
            report["parada"] = "concluido_com_erros"
    except KeyboardInterrupt:
        report["parada"] = "interrompido"
        LOG.warning("Interrompido pelo usuário")
    finally:
        report["total_requisicoes"] = client.count
        report["fim"] = datetime.now(timezone.utc).isoformat()
        (config.output_dir / "relatorio.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        client.close()
    return report
